/*
 * Copyright 2011 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.codenarc.rule.security

import org.codehaus.groovy.ast.expr.MethodCallExpression
import org.codenarc.rule.AbstractAstVisitorRule
import org.codenarc.rule.AbstractMethodCallExpressionVisitor
import org.codenarc.util.AstUtil

/**
 * The File.createTempFile() method is insecure, and has been deprecated by the ESAPI secure coding library.
 * It has been replaced by the ESAPI Randomizer.getRandomFilename(String) method.
 *
 * By default, this rule does not apply to test files.
 *
 * @author Hamlet D'Arcy
 */
class FileCreateTempFileRule extends AbstractAstVisitorRule {
    String name = 'FileCreateTempFile'
    int priority = 2
    Class astVisitorClass = FileCreateTempFileAstVisitor
    String doNotApplyToFilesMatching = DEFAULT_TEST_FILES
}

class FileCreateTempFileAstVisitor extends AbstractMethodCallExpressionVisitor {

    @Override
    void visitMethodCallExpression(MethodCallExpression call) {

        if (AstUtil.isMethodCall(call, 'File', 'createTempFile', 2) ||
                AstUtil.isMethodCall(call, 'File', 'createTempFile', 3)) {
            addViolation(call, 'The method File.createTempFile is insecure. Use a secure API such as that provided by ESAPI')
        }
    }
}
